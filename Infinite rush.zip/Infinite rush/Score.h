#ifndef SCORE_H
#define SCORE_H

#pragma once

#include <SFML/Graphics.hpp>

class Score {
public:
    Score();

    void increaseScore(int amount);
    void update();
    void draw(sf::RenderWindow& window);

private:
    int score;
    sf::Font font;
    sf::Text scoreText;
};


#endif // SCORE_H

#include "obstacle.h"


SquareObstacle::SquareObstacle(float xPos, float yPos, const std::string& obstacleImagePath) {
    if (!texture.loadFromFile(obstacleImagePath)) {
        // Handle error if the image fails to load
    }
    sprite.setTexture(texture);
    sprite.setPosition(xPos, yPos);
    speed = 2.f;
}
CircleObstacle::CircleObstacle(float xPos, float yPos, const std::string& obstacleImagePath) {
    if (!texture.loadFromFile(obstacleImagePath)) {
        // Handle error if the image fails to load
    }
    sprite.setTexture(texture);
    sprite.setPosition(xPos, yPos);
    speed = 2.f;
}

TriangleObstacle::TriangleObstacle(float xPos, float yPos, const std::string& obstacleImagePath) {
    if (!texture.loadFromFile(obstacleImagePath)) {
        // Handle error if the image fails to load
    }
    sprite.setTexture(texture);
    sprite.setPosition(xPos, yPos);
    speed = 2.f;
}





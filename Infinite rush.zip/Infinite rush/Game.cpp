﻿#include <SFML/Graphics.hpp>
#include <SFML/System/Clock.hpp>
#include <SFML/System/Sleep.hpp>
#include <SFML/Audio.hpp>
#include <iostream>
#include <vector>
#include <cstdlib> // for random number generation
#include <ctime>   // for seeding random number generator

#include "character.h"
#include "obstacle.h"
#include "background.h"

bool checkCollision(const sf::FloatRect& rect1, const sf::FloatRect& rect2) {
    return rect1.intersects(rect2);
}

bool checkObstacleCollision(const sf::FloatRect& rect, const std::vector<Obstacle*>& obstacles) {
    for (const auto& obstacle : obstacles) {
        if (checkCollision(rect, obstacle->getBounds())) {
            return true;
        }
    }
    return false;
}

bool isMouseOver(const sf::FloatRect& bounds, const sf::RenderWindow& window) {
    sf::Vector2i mousePosition = sf::Mouse::getPosition(window);
    return bounds.contains(static_cast<float>(mousePosition.x), static_cast<float>(mousePosition.y));
}

void animateGameOver(sf::RenderWindow& window, sf::Text& gameOverText) {
    sf::Clock clock;
    sf::Time elapsed;

    sf::Vector2f originalPosition = gameOverText.getPosition();
    float finalYPosition = (window.getSize().y - gameOverText.getGlobalBounds().height) / 2;

    while (window.isOpen()) {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed)
                window.close();
        }

        elapsed = clock.restart();

        float deltaTime = elapsed.asSeconds();
        float animationSpeed = 200.f; // Adjust the animation speed as desired

        // Animate the "Game Over" text
        float currentYPosition = gameOverText.getPosition().y;
        if (currentYPosition < finalYPosition) {
            float newYPosition = currentYPosition + animationSpeed * deltaTime;
            gameOverText.setPosition(originalPosition.x, newYPosition);
        }
        else {
            gameOverText.setPosition(originalPosition.x, finalYPosition);
        }

        window.clear();
        window.draw(gameOverText);
        window.display();

        if (currentYPosition >= finalYPosition) {
            sf::sleep(sf::seconds(3)); // Display "Game Over" for 3 seconds before closing the window
            window.close();             // Close the window after game over
            break;
        }
    }
}

int main() {
    sf::RenderWindow window(sf::VideoMode(800, 600), "Infinite Rush");

    Character character;
    std::vector<Obstacle*> obstacles;

    std::srand(static_cast<unsigned int>(std::time(nullptr))); // Seed random number generator

    Background background;

    float speed = 2.f;
    int score = 0;
    int highestScore = 0;
    int levelThreshold = 300;
    int level = 3;
    bool gameOver = false;
    bool gameStarted = false; // Flag to track if the game has started
    bool guideShown = false;  // Flag to track if the guide has been shown

    sf::Clock clock;
    sf::Time elapsed;
    sf::Time obstacleSpawnDelay = sf::seconds(2.f);
    sf::Time obstacleTimer = sf::Time::Zero;
    sf::Time scoreIncreaseDelay = sf::seconds(1.f);
    sf::Time scoreTimer = sf::Time::Zero;

    sf::Font font;
    font.loadFromFile("28 Days Later.ttf");

    sf::Text startOption;
    startOption.setFont(font);
    startOption.setString("Start");
    startOption.setCharacterSize(50);
    startOption.setFillColor(sf::Color::White);
    startOption.setPosition((window.getSize().x - startOption.getGlobalBounds().width) / 2, window.getSize().y / 2 - startOption.getGlobalBounds().height - 20);

    sf::Text guideOption;
    guideOption.setFont(font);
    guideOption.setString("Guide");
    guideOption.setCharacterSize(50);
    guideOption.setFillColor(sf::Color::White);
    guideOption.setPosition((window.getSize().x - guideOption.getGlobalBounds().width) / 2, window.getSize().y / 2);

    sf::Text leaveOption;
    leaveOption.setFont(font);
    leaveOption.setString("Leave");
    leaveOption.setCharacterSize(50);
    leaveOption.setFillColor(sf::Color::White);
    leaveOption.setPosition((window.getSize().x - leaveOption.getGlobalBounds().width) / 2, window.getSize().y / 2 + leaveOption.getGlobalBounds().height + 20);

    sf::Text backButton;
    backButton.setFont(font);
    backButton.setString("BACK");
    backButton.setCharacterSize(40);
    backButton.setFillColor(sf::Color::White);
    backButton.setPosition(10, window.getSize().y - backButton.getGlobalBounds().height - 10);

    sf::Text title;
    title.setFont(font);
    title.setString("INFINITE RUSH");
    title.setCharacterSize(60);
    title.setFillColor(sf::Color::White);
    title.setPosition((window.getSize().x - title.getGlobalBounds().width) / 2, 50);

    sf::Text guideText;
    guideText.setFont(font);
    guideText.setString("Move your character up and down\nby their respective arrows\nand do not hit any obstacle");
    guideText.setCharacterSize(30);
    guideText.setFillColor(sf::Color::White);
    guideText.setPosition((window.getSize().x - guideText.getGlobalBounds().width) / 2, window.getSize().y / 2);

    sf::Text gameOverText;
    gameOverText.setFont(font);
    gameOverText.setString("Game Over");
    gameOverText.setCharacterSize(80);
    gameOverText.setFillColor(sf::Color::Red);
    gameOverText.setPosition((window.getSize().x - gameOverText.getGlobalBounds().width) / 2, -gameOverText.getGlobalBounds().height);

    sf::Music backgroundMusic;

    if (!backgroundMusic.openFromFile("Resources/background.ogg")) { // Replace with your file
        std::cerr << "Error loading background music\n";
        return -1;
    }

    backgroundMusic.setLoop(true); // Set the music to loop if it reaches the end

    backgroundMusic.play();
    while (window.isOpen()) {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed)
                window.close();
            else if (event.type == sf::Event::MouseButtonPressed) {
                if (event.mouseButton.button == sf::Mouse::Left) {
                    sf::Vector2i mousePosition = sf::Mouse::getPosition(window);
                    if (startOption.getGlobalBounds().contains(static_cast<float>(mousePosition.x), static_cast<float>(mousePosition.y))) {
                        gameStarted = true;
                    }
                    else if (guideOption.getGlobalBounds().contains(static_cast<float>(mousePosition.x), static_cast<float>(mousePosition.y))) {
                        guideShown = true;
                    }
                    else if (leaveOption.getGlobalBounds().contains(static_cast<float>(mousePosition.x), static_cast<float>(mousePosition.y))) {
                        window.close(); // Close the window to quit the game
                    }
                    else if (guideShown && backButton.getGlobalBounds().contains(static_cast<float>(mousePosition.x), static_cast<float>(mousePosition.y))) {
                        guideShown = false; // Go back to the title screen
                    }
                }
            }
        }

        elapsed = clock.restart();

        if (gameStarted && !gameOver) {
            if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up)) {
                character.moveUp();
            }
            if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down)) {
                character.moveDown();
            }
        }

        if (gameStarted) {
            if (obstacleTimer >= obstacleSpawnDelay) {
                float randomY = static_cast<float>(std::rand() % (600 - 50));

                // Randomly choose an obstacle type
                int obstacleType = std::rand() % 3;
                sf::Color obstacleColor(std::rand() % 256, std::rand() % 256, std::rand() % 256);

                std::string obstacleImagePath;
                if (obstacleType == 0) {
                    obstacleImagePath = "Resources/image1.png";
                }
                else if (obstacleType == 1) {
                    obstacleImagePath = "Resources/image2.png";
                }
                else {
                    obstacleImagePath = "Resources/image3.png";
                }

                if (!obstacleImagePath.empty()) {
                    if (obstacleType == 0) {
                        obstacles.push_back(new SquareObstacle(800.f, randomY, obstacleImagePath));
                    }
                    else if (obstacleType == 1) {
                        obstacles.push_back(new CircleObstacle(800.f, randomY, obstacleImagePath));
                    }
                    else {
                        obstacles.push_back(new TriangleObstacle(800.f, randomY, obstacleImagePath));
                    }
                }

                obstacleTimer = sf::Time::Zero;
            }
            else {
                obstacleTimer += elapsed;
            }

            if (scoreTimer >= scoreIncreaseDelay) {
                score += 1;
                scoreTimer = sf::Time::Zero;
            }
            else {
                scoreTimer += elapsed;
            }
        }

        window.clear();



        if (!gameStarted && !guideShown) {
            if (isMouseOver(startOption.getGlobalBounds(), window)) {
                startOption.setFillColor(sf::Color(128, 0, 0, 200)); // Light maroon color with opacity
            }
            else {
                startOption.setFillColor(sf::Color::White);
            }
            if (isMouseOver(guideOption.getGlobalBounds(), window)) {
                guideOption.setFillColor(sf::Color(128, 0, 0, 200)); // Light maroon color with opacity
            }
            else {
                guideOption.setFillColor(sf::Color::White);
            }
            if (isMouseOver(leaveOption.getGlobalBounds(), window)) {
                leaveOption.setFillColor(sf::Color(128, 0, 0, 200)); // Light maroon color with opacity
            }
            else {
                leaveOption.setFillColor(sf::Color::White);
            }

            window.draw(startOption);
            window.draw(guideOption);
            window.draw(leaveOption);
        }
        else if (guideShown) {
            window.draw(guideText);
            window.draw(backButton);
        }
        else {
            background.draw(window);

            character.draw(window);

            for (auto& obstacle : obstacles) {
                obstacle->update();

                if (checkCollision(character.getBounds(), obstacle->getBounds())) {
                    std::cout << "Game Over!" << std::endl;
                    gameOver = true;
                    if (score > highestScore) {
                        highestScore = score;
                    }
                    animateGameOver(window, gameOverText);
                    break;
                }

                obstacle->draw(window);
            }
            sf::Text scoreText;
            scoreText.setFont(font);
            scoreText.setString("Score " + std::to_string(score));
            scoreText.setCharacterSize(30);
            scoreText.setFillColor(sf::Color::White);
            scoreText.setPosition(10, 10);
            window.draw(scoreText);
        }

        if (!gameStarted) {
            window.draw(title);
        }

        window.display();

        sf::sleep(sf::milliseconds(10)); // Delay to control game speed
    }

    // Clean up the dynamically allocated obstacles
    for (auto& obstacle : obstacles) {
        delete obstacle;
    }

    return 0;
}

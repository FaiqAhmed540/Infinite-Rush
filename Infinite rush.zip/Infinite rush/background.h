#ifndef BACKGROUND_H
#define BACKGROUND_H

#include <SFML/Graphics.hpp>

class Background {
private:
    sf::Texture texture;
    sf::Sprite sprite;

public:
    Background();

    void draw(sf::RenderWindow& window);
};

#endif // BACKGROUND_H

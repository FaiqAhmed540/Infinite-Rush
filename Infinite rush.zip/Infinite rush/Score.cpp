#include "Score.h"

Score::Score() {
    score = 0;
    font.loadFromFile("FadeToGrey.ttf");
    scoreText.setFont(font);
    scoreText.setCharacterSize(30);
    scoreText.setFillColor(sf::Color::White);
    scoreText.setPosition(10, 10);
}

void Score::increaseScore(int amount) {
    score += amount;
}

void Score::update() {
    // Update the score logic here
}

void Score::draw(sf::RenderWindow& window) {
    // Draw the score on the window
    scoreText.setString("Score: " + std::to_string(score));
    window.draw(scoreText);
}


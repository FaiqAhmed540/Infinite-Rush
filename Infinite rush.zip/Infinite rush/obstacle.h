#ifndef OBSTACLE_H
#define OBSTACLE_H

#include <SFML/Graphics.hpp>

class Obstacle {
protected:
    sf::Texture texture;
    sf::Sprite sprite;
    float speed;

public:
    virtual ~Obstacle() {}

    void update() {
        sprite.move(-speed, 0.f);

        // Check if obstacle is outside the window
        if (sprite.getPosition().x + sprite.getLocalBounds().width < 0.f) {
            sprite.setPosition(800.f, sprite.getPosition().y);
        }
    }

    sf::FloatRect getBounds() const {
        return sprite.getGlobalBounds();
    }

    void draw(sf::RenderWindow& window) {
        window.draw(sprite);
    }
};

class SquareObstacle : public Obstacle {
public:
    SquareObstacle(float xPos, float yPos, const std::string& obstacleImagePath);
};

class CircleObstacle : public Obstacle {
public:
    CircleObstacle(float xPos, float yPos, const std::string& obstacleImagePath);
};

class TriangleObstacle : public Obstacle {
public:
    TriangleObstacle(float xPos, float yPos, const std::string& obstacleImagePath);
};

#endif // OBSTACLE_H

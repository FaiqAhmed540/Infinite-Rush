#include "background.h"
#include <iostream>

Background::Background() {
    if (!texture.loadFromFile("Resources/Background.png")) {
        std::cout << "Failed to load background image." << std::endl;
        return;
    }
    texture.setRepeated(true);

    sprite.setTexture(texture);
    sprite.setTextureRect(sf::IntRect(0, 0, 800, 600));
}

void Background::draw(sf::RenderWindow& window) {
    window.draw(sprite);
}

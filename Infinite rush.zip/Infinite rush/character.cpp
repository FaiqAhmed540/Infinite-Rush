#include "character.h"

Character::Character() {
    if (!characterTexture.loadFromFile("Resources/character.png")) {
        // handle error
    }
    characterSprite.setTexture(characterTexture);
    characterSprite.setPosition(45.f, 275.f); // Adjusted initial position
    speed = 5.f;
}

void Character::moveUp() {
    if (characterSprite.getPosition().y > 0.f)
        characterSprite.move(0.f, -speed);
}

void Character::moveDown() {
    if (characterSprite.getPosition().y + characterSprite.getGlobalBounds().height < 600.f)
        characterSprite.move(0.f, speed);
}

sf::FloatRect Character::getBounds() const {
    return characterSprite.getGlobalBounds();
}

void Character::draw(sf::RenderWindow& window) {
    window.draw(characterSprite);
}

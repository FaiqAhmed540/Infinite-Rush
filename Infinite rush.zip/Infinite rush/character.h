#ifndef CHARACTER_H
#define CHARACTER_H

#include <SFML/Graphics.hpp>

class Character {
private:
    sf::Texture characterTexture;
    sf::Sprite characterSprite;
    float speed;

public:
    Character();

    void moveUp();
    void moveDown();
    sf::FloatRect getBounds() const;
    void draw(sf::RenderWindow& window);
    sf::Vector2f getPosition() const {
        return characterSprite.getPosition();
    }
    };

    
#endif // CHARACTER_H
